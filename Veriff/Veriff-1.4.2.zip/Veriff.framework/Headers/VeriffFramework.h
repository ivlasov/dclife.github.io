//
//  VeriffFramework.h
//  VeriffFramework
//
//  Copyright © 2016 Veriff. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <VeriffFramework/Veriff.h>

//! Project version number for VeriffFramework.
FOUNDATION_EXPORT double VeriffFrameworkVersionNumber;

//! Project version string for VeriffFramework.
FOUNDATION_EXPORT const unsigned char VeriffFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VeriffFramework/PublicHeader.h>


